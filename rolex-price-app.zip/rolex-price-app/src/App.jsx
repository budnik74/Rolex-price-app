import { useState, useEffect, useRef } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";

// ─── Constants ────────────────────────────────────────────────────────────────
const ROLEX_MODELS = [
  "Rolex Submariner Date","Rolex Daytona","Rolex GMT-Master II",
  "Rolex Datejust 41","Rolex Day-Date 40","Rolex Explorer II",
  "Rolex Yacht-Master II","Rolex Milgauss","Rolex Air-King",
  "Rolex Oyster Perpetual 41","Rolex Sky-Dweller","Rolex Sea-Dweller",
  "Rolex Explorer","Rolex Datejust 36","Rolex Yacht-Master 40",
];

const SORT_OPTIONS = [
  { label:"Default",   value:"default"   },
  { label:"Price ↑",   value:"price_asc" },
  { label:"Price ↓",   value:"price_desc"},
  { label:"Savings ↓", value:"savings"   },
  { label:"Name A–Z",  value:"name"      },
];

const CONDITION_FILTERS = ["All","new","pre-owned","certified pre-owned"];

// Dial colour swatches
const DIAL_COLORS = [
  { id:"All",        label:"All",        hex:"transparent", border:"rgba(197,158,71,0.4)" },
  { id:"Black",      label:"Black",      hex:"#1a1a1a" },
  { id:"White",      label:"White",      hex:"#f0ede6" },
  { id:"Blue",       label:"Blue",       hex:"#1b3a6b" },
  { id:"Green",      label:"Green",      hex:"#1c4530" },
  { id:"Silver",     label:"Silver",     hex:"#a8a8a8" },
  { id:"Champagne",  label:"Champagne",  hex:"#c8a96e" },
  { id:"Chocolate",  label:"Chocolate",  hex:"#4a2d1a" },
  { id:"Grey",       label:"Grey",       hex:"#5a5a5a" },
  { id:"Pink",       label:"Pink",       hex:"#d48a8a" },
  { id:"Rhodium",    label:"Rhodium",    hex:"#8a8a9a" },
  { id:"Meteorite",  label:"Meteorite",  hex:"#3d3530" },
];

// Case sizes (mm)
const CASE_SIZES = ["All","36mm","40mm","41mm","42mm","44mm","45mm"];

const TABS = ["GRID","WATCHLIST","COMPARE"];

const gold  = "#c59e47";
const gold2 = "rgba(197,158,71,0.18)";
const gold3 = "rgba(197,158,71,0.06)";
const bg    = "#080604";
const text  = "#e8d5a3";

const fmt = (p) => p != null ? "$" + Number(p).toLocaleString("en-US") : "—";

const genHistory = (price) => {
  if (!price) return [];
  const months = ["Oct","Nov","Dec","Jan","Feb","Mar","Apr"];
  let cur = price * (1 + (Math.random() * 0.18 - 0.09));
  return months.map(m => {
    cur = cur * (1 + (Math.random() * 0.06 - 0.025));
    return { month:m, price:Math.round(cur) };
  }).concat([{ month:"Now", price }]);
};

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;600;700&family=Rajdhani:wght@300;400;500;600&display=swap');
@keyframes pulse  { 0%,100%{opacity:1} 50%{opacity:0.22} }
@keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
@keyframes shimmer{ 0%{background-position:-200% center} 100%{background-position:200% center} }
@keyframes glow   { 0%,100%{box-shadow:0 0 8px rgba(197,158,71,0.22)} 50%{box-shadow:0 0 22px rgba(197,158,71,0.6)} }
@keyframes cardIn { from{opacity:0;transform:translateY(26px) scale(0.97)} to{opacity:1;transform:translateY(0) scale(1)} }
@keyframes swatchPop { from{transform:scale(0.7);opacity:0} to{transform:scale(1);opacity:1} }
* { box-sizing:border-box; }
::-webkit-scrollbar { width:4px; background:#0d0a05; }
::-webkit-scrollbar-thumb { background:rgba(197,158,71,0.25); }
`;

const ChartTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background:"#0d0a05", border:"1px solid rgba(197,158,71,0.35)", padding:"8px 14px", fontSize:12, fontFamily:"'Rajdhani',sans-serif", color:text }}>
      <div style={{ color:"rgba(197,158,71,0.55)", letterSpacing:"0.15em", fontSize:10, marginBottom:3 }}>{label}</div>
      <div style={{ color:gold, fontSize:15 }}>{fmt(payload[0].value)}</div>
    </div>
  );
};

// ─── Watch face SVG preview ───────────────────────────────────────────────────
const WatchFace = ({ dialColor = "#1a1a1a", size = 60 }) => {
  const c = DIAL_COLORS.find(d => d.id === dialColor);
  const dialHex = c?.hex || "#1a1a1a";
  const isLight = ["White","Silver","Pink","Champagne"].includes(dialColor);
  const handColor = isLight ? "#222" : "#e8d5a3";
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      {/* Bezel */}
      <circle cx="50" cy="50" r="48" fill="none" stroke={gold} strokeWidth="3.5"/>
      <circle cx="50" cy="50" r="44" fill={gold} opacity="0.15"/>
      {/* Dial */}
      <circle cx="50" cy="50" r="40" fill={dialHex}/>
      {/* Hour markers */}
      {Array.from({length:12},(_,i) => {
        const a = (i*30 - 90) * Math.PI/180;
        const r1=33, r2=38;
        return <line key={i}
          x1={50+r1*Math.cos(a)} y1={50+r1*Math.sin(a)}
          x2={50+r2*Math.cos(a)} y2={50+r2*Math.sin(a)}
          stroke={isLight?"rgba(0,0,0,0.5)":"rgba(255,255,255,0.6)"} strokeWidth={i%3===0?2:1}/>;
      })}
      {/* Hour hand */}
      <line x1="50" y1="50" x2="50" y2="22" stroke={handColor} strokeWidth="3" strokeLinecap="round"/>
      {/* Minute hand */}
      <line x1="50" y1="50" x2="68" y2="34" stroke={handColor} strokeWidth="2" strokeLinecap="round"/>
      {/* Crown dot */}
      <circle cx="50" cy="50" r="3" fill={gold}/>
      {/* Crown */}
      <rect x="88" y="44" width="5" height="12" rx="2" fill={gold} opacity="0.7"/>
    </svg>
  );
};

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [results,     setResults]     = useState({});
  const [loading,     setLoading]     = useState({});
  const [history,     setHistory]     = useState({});
  const [scanning,    setScanning]    = useState(false);
  const [progress,    setProgress]    = useState(0);
  const [scanDone,    setScanDone]    = useState(false);
  const [selected,    setSelected]    = useState(null);
  const [tab,         setTab]         = useState("GRID");
  const [watchlist,   setWatchlist]   = useState([]);
  const [alerts,      setAlerts]      = useState({});
  const [alertInput,  setAlertInput]  = useState({});
  const [triggered,   setTriggered]   = useState([]);
  const [compareSet,  setCompareSet]  = useState([]);
  const [sortBy,      setSortBy]      = useState("default");
  const [condFilter,  setCondFilter]  = useState("All");
  const [searchQ,     setSearchQ]     = useState("");
  // NEW
  const [colorFilter, setColorFilter] = useState("All");
  const [sizeFilter,  setSizeFilter]  = useState("All");

  const canvasRef = useRef(null);
  const animRef   = useRef(null);

  useEffect(() => {
    const el = document.createElement("style");
    el.textContent = CSS;
    document.head.appendChild(el);
    return () => document.head.removeChild(el);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let w = canvas.width=window.innerWidth, h=canvas.height=window.innerHeight;
    const pts = Array.from({length:50},()=>({ x:Math.random()*w, y:Math.random()*h, r:Math.random()*1.2+0.2, dx:(Math.random()-0.5)*0.25, dy:(Math.random()-0.5)*0.25, a:Math.random()*0.4+0.07 }));
    const draw=()=>{ ctx.clearRect(0,0,w,h); pts.forEach(p=>{ ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=`rgba(197,158,71,${p.a})`;ctx.fill();p.x+=p.dx;p.y+=p.dy;if(p.x<0||p.x>w)p.dx*=-1;if(p.y<0||p.y>h)p.dy*=-1;}); animRef.current=requestAnimationFrame(draw); };
    draw();
    const onR=()=>{ w=canvas.width=window.innerWidth; h=canvas.height=window.innerHeight; };
    window.addEventListener("resize",onR);
    return ()=>{ cancelAnimationFrame(animRef.current); window.removeEventListener("resize",onR); };
  },[]);

  useEffect(() => {
    const fired=[];
    Object.entries(alerts).forEach(([model,target])=>{ const r=results[model]; if(r?.lowestPrice&&target&&r.lowestPrice<=Number(target)) fired.push({model,price:r.lowestPrice,target}); });
    if(fired.length) setTriggered(prev=>{ const ex=prev.map(f=>f.model); return [...prev,...fired.filter(f=>!ex.includes(f.model))]; });
  },[results,alerts]);

  // ── API fetch ────────────────────────────────────────────────────────────────
  const fetchModel = async (model, opts = {}) => {
    const { dialColor, caseSize } = opts;
    const key = dialColor || caseSize ? `${model}|${dialColor||""}|${caseSize||""}` : model;
    setLoading(p=>({...p,[key]:true}));
    const colorSpec = dialColor && dialColor !== "All" ? ` with ${dialColor} dial` : "";
    const sizeSpec  = caseSize  && caseSize  !== "All" ? ` in ${caseSize} case size` : "";
    const query = `${model}${colorSpec}${sizeSpec}`;
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514", max_tokens:1200,
          tools:[{type:"web_search_20250305",name:"web_search"}],
          system:`You are a luxury watch market analyst. Search the internet for the CURRENT lowest verified price for the specific Rolex model configuration described. Search Chrono24, eBay authenticated, WatchBox, Bob's Watches, Crown & Caliber, Tourneau, and Rolex.com.

Return ONLY valid JSON, no markdown, no preamble:
{
  "model": "<full model name>",
  "dialColor": "<actual dial color found, e.g. Black, Blue, Green, White, Champagne, etc.>",
  "caseSize": "<case diameter e.g. 41mm>",
  "material": "<case material e.g. Oystersteel, White Gold, Yellow Gold, Rolesor>",
  "bracelet": "<bracelet type e.g. Oyster, Jubilee, Oysterflex>",
  "lowestPrice": <number|null>,
  "retailMSRP": <number|null>,
  "source": "<marketplace>",
  "sourceUrl": "<url|empty>",
  "condition": "new|pre-owned|certified pre-owned",
  "referenceNumber": "<ref|empty>",
  "savings": <positive number|null>,
  "priceRange": {"low":<number>,"high":<number>},
  "verified": true,
  "marketNote": "<one sentence insight>"
}`,
          messages:[{role:"user",content:`Find best current lowest verified price for: ${query}. Search all major trusted watch marketplaces now.`}],
        }),
      });
      const data=await res.json();
      const block=data.content?.find(b=>b.type==="text");
      const raw=block?.text||"{}";
      const clean=raw.replace(/```json|```/g,"").trim();
      const parsed=JSON.parse(clean);
      setResults(p=>({...p,[key]:parsed}));
      if(parsed.lowestPrice) setHistory(p=>({...p,[key]:genHistory(parsed.lowestPrice)}));
    } catch {
      setResults(p=>({...p,[key]:{model,error:"Search failed. Tap to retry.",verified:false}}));
    }
    setLoading(p=>({...p,[key]:false}));
  };

  const scanAll = async () => {
    setScanning(true); setScanDone(false); setProgress(0); setResults({}); setHistory({});
    for(let i=0;i<ROLEX_MODELS.length;i++){
      await fetchModel(ROLEX_MODELS[i]);
      setProgress(Math.round(((i+1)/ROLEX_MODELS.length)*100));
    }
    setScanDone(true); setScanning(false);
  };

  // Key used when color/size filters are active
  const activeKey = (model) => {
    const c = colorFilter !== "All" ? colorFilter : "";
    const z = sizeFilter  !== "All" ? sizeFilter  : "";
    return c || z ? `${model}|${c}|${z}` : model;
  };

  const bestDeal = Object.values(results).reduce((best,r)=>{
    if(!r?.lowestPrice) return best;
    return (!best||r.lowestPrice<best.lowestPrice)?r:best;
  },null);

  const filteredModels = ROLEX_MODELS
    .filter(m => {
      const r = results[activeKey(m)];
      if(searchQ && !m.toLowerCase().includes(searchQ.toLowerCase())) return false;
      if(condFilter!=="All" && r?.condition && r.condition!==condFilter) return false;
      if(colorFilter!=="All" && r?.dialColor && !r.dialColor.toLowerCase().includes(colorFilter.toLowerCase())) return false;
      if(sizeFilter!=="All"  && r?.caseSize  && !r.caseSize.toLowerCase().includes(sizeFilter.replace("mm","").trim())) return false;
      return true;
    })
    .sort((a,b)=>{
      const ra=results[activeKey(a)], rb=results[activeKey(b)];
      if(sortBy==="price_asc")  return (ra?.lowestPrice||Infinity)-(rb?.lowestPrice||Infinity);
      if(sortBy==="price_desc") return (rb?.lowestPrice||0)-(ra?.lowestPrice||0);
      if(sortBy==="savings")    return (rb?.savings||0)-(ra?.savings||0);
      if(sortBy==="name")       return a.localeCompare(b);
      return 0;
    });

  const toggleWatchlist = m => setWatchlist(w=>w.includes(m)?w.filter(x=>x!==m):[...w,m]);
  const toggleCompare   = m => setCompareSet(c=>c.includes(m)?c.filter(x=>x!==m):c.length<3?[...c,m]:c);
  const setAlert = (model) => {
    const val=alertInput[model]; if(!val||isNaN(val)) return;
    setAlerts(a=>({...a,[model]:Number(val)}));
    setAlertInput(ai=>({...ai,[model]:""}));
  };

  const selectedKey  = selected ? activeKey(selected) : null;
  const selectedData = selectedKey ? results[selectedKey] : null;

  // ── Styles ───────────────────────────────────────────────────────────────────
  const s = {
    root:      {fontFamily:"'Rajdhani',sans-serif",background:bg,minHeight:"100vh",color:text,position:"relative"},
    canvas:    {position:"fixed",inset:0,width:"100%",height:"100%",pointerEvents:"none",zIndex:0},
    wrap:      {position:"relative",zIndex:1,maxWidth:1300,margin:"0 auto",padding:"0 20px 80px"},
    header:    {textAlign:"center",padding:"46px 0 30px",borderBottom:`1px solid ${gold2}`,marginBottom:32},
    crown:     {fontSize:32,marginBottom:8,display:"block"},
    title:     {fontFamily:"'Cormorant Garamond',serif",fontSize:"clamp(1.8rem,5vw,3.4rem)",fontWeight:300,letterSpacing:"0.22em",margin:0,background:"linear-gradient(120deg,#a07830 0%,#f0d080 40%,#c59e47 60%,#a07830 100%)",backgroundSize:"200% auto",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",animation:"shimmer 4s linear infinite"},
    sub:       {fontSize:11,letterSpacing:"0.35em",color:"rgba(197,158,71,0.45)",margin:"8px 0 0",textTransform:"uppercase"},
    tabBar:    {display:"flex",justifyContent:"center",gap:4,margin:"0 0 28px"},
    tabBtn:    (a)=>({fontFamily:"'Rajdhani',sans-serif",fontSize:12,letterSpacing:"0.22em",textTransform:"uppercase",padding:"9px 26px",cursor:"pointer",border:"1px solid",borderColor:a?gold:gold2,background:a?"rgba(197,158,71,0.1)":"transparent",color:a?gold:"rgba(197,158,71,0.45)",transition:"all 0.22s"}),
    scanWrap:  {display:"flex",flexDirection:"column",alignItems:"center",gap:13,marginBottom:28},
    scanBtn:   {fontFamily:"'Rajdhani',sans-serif",fontSize:13,fontWeight:600,letterSpacing:"0.22em",textTransform:"uppercase",background:"transparent",border:`1px solid ${gold}`,color:gold,padding:"12px 40px",cursor:"pointer",animation:"glow 2.5s ease-in-out infinite",transition:"background 0.22s"},
    progOut:   {width:380,maxWidth:"86vw",height:2,background:"rgba(197,158,71,0.1)",overflow:"hidden"},
    progIn:    {height:"100%",background:"linear-gradient(90deg,#7a5a20,#f0d080,#7a5a20)",backgroundSize:"200% 100%",animation:"shimmer 1.4s linear infinite",transition:"width 0.4s ease"},
    progLbl:   {fontSize:10,letterSpacing:"0.2em",color:"rgba(197,158,71,0.45)"},
    banner:    {background:gold3,border:`1px solid rgba(197,158,71,0.28)`,padding:"10px 24px",fontSize:13,letterSpacing:"0.06em",color:text,maxWidth:560,textAlign:"center"},

    // filter panel
    filterPanel:{background:"rgba(8,6,4,0.95)",border:`1px solid ${gold2}`,padding:"18px 20px",marginBottom:24},
    filterRow:  {display:"flex",flexWrap:"wrap",gap:10,alignItems:"center",marginBottom:14},
    filterLbl:  {fontSize:10,letterSpacing:"0.2em",textTransform:"uppercase",color:"rgba(197,158,71,0.45)",minWidth:60},
    searchInp:  {fontFamily:"'Rajdhani',sans-serif",fontSize:13,letterSpacing:"0.08em",background:"transparent",border:`1px solid ${gold2}`,color:text,padding:"6px 12px",outline:"none",width:180},
    selEl:      {fontFamily:"'Rajdhani',sans-serif",fontSize:12,letterSpacing:"0.1em",background:"#0d0a05",border:`1px solid ${gold2}`,color:text,padding:"6px 10px",cursor:"pointer",outline:"none"},
    divider:    {borderTop:`1px solid ${gold2}`,margin:"12px 0"},

    // color swatches
    swatchRow:  {display:"flex",flexWrap:"wrap",gap:8,alignItems:"center"},
    swatch:     (active, hex, border)=>({
      width:26, height:26, borderRadius:"50%", cursor:"pointer",
      background: hex==="transparent" ? "rgba(197,158,71,0.08)" : hex,
      border:`2px solid ${active?"#c59e47":(border||"rgba(255,255,255,0.12)")}`,
      boxShadow: active?"0 0 8px rgba(197,158,71,0.7)":"none",
      transition:"all 0.2s", position:"relative",
      display:"flex",alignItems:"center",justifyContent:"center",
    }),
    swatchAll:  {fontSize:8,color:gold,fontWeight:700,letterSpacing:"0.05em"},

    // size pills
    sizePill:   (active)=>({
      fontFamily:"'Rajdhani',sans-serif", fontSize:11, letterSpacing:"0.14em",
      padding:"4px 12px", cursor:"pointer", border:"1px solid",
      borderColor: active ? gold : gold2,
      background:  active ? "rgba(197,158,71,0.12)" : "transparent",
      color:       active ? gold : "rgba(197,158,71,0.5)",
      transition:"all 0.2s",
    }),

    // grid
    grid:      {display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(252px,1fr))",gap:16},
    card:      (isBest,idx)=>({background:isBest?"rgba(197,158,71,0.05)":"rgba(10,8,4,0.9)",border:`1px solid ${isBest?"rgba(197,158,71,0.6)":gold2}`,padding:"18px 16px",position:"relative",overflow:"hidden",transition:"border-color 0.26s,transform 0.18s",animation:"cardIn 0.48s ease both",animationDelay:`${idx*0.035}s`,cursor:"pointer"}),
    bestTag:   {position:"absolute",top:0,right:0,background:gold,color:bg,fontSize:9,fontWeight:700,letterSpacing:"0.13em",padding:"3px 9px"},
    cardHead:  {display:"flex",gap:10,alignItems:"flex-start",marginBottom:10},
    modelName: {fontFamily:"'Cormorant Garamond',serif",fontSize:15,fontWeight:600,color:text,letterSpacing:"0.03em",flex:1},
    priceNum:  {fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:700,color:gold,display:"block"},
    savTag:    {fontSize:10,color:"#4ade80",letterSpacing:"0.08em",marginTop:2,display:"block"},
    metaRow:   {display:"flex",flexWrap:"wrap",gap:4,marginTop:8},
    metaPill:  {fontSize:9,letterSpacing:"0.1em",color:"rgba(232,213,163,0.4)",border:`1px solid ${gold2}`,padding:"2px 6px",textTransform:"uppercase"},
    verBadge:  {fontSize:9,letterSpacing:"0.1em",color:"#4ade80",border:"1px solid rgba(74,222,128,0.28)",padding:"2px 6px",textTransform:"uppercase"},
    dialBadge: (hex)=>({display:"inline-flex",alignItems:"center",gap:4,fontSize:9,letterSpacing:"0.1em",color:"rgba(232,213,163,0.5)",border:`1px solid ${gold2}`,padding:"2px 6px",textTransform:"uppercase"}),
    dialDot:   (hex)=>({width:8,height:8,borderRadius:"50%",background:hex,border:"1px solid rgba(255,255,255,0.2)",flexShrink:0}),
    cardBtns:  {display:"flex",gap:5,marginTop:11},
    iconBtn:   (active,color)=>({flex:1,fontFamily:"'Rajdhani',sans-serif",fontSize:10,letterSpacing:"0.13em",textTransform:"uppercase",background:active?`rgba(${color},0.12)`:"transparent",border:`1px solid rgba(${color},${active?0.55:0.22})`,color:`rgba(${color},${active?1:0.5})`,padding:"5px 4px",cursor:"pointer",transition:"all 0.2s"}),
    fetchBtn:  {fontFamily:"'Rajdhani',sans-serif",fontSize:11,letterSpacing:"0.16em",textTransform:"uppercase",background:"transparent",border:`1px solid rgba(197,158,71,0.3)`,color:"rgba(197,158,71,0.6)",padding:"7px 14px",cursor:"pointer",width:"100%",transition:"all 0.2s"},
    dotWrap:   {display:"flex",alignItems:"center",gap:4},
    dot:       (d)=>({width:5,height:5,borderRadius:"50%",background:gold,display:"inline-block",animation:`pulse 1s ease-in-out ${d}s infinite`}),
    scanTxt:   {fontSize:11,letterSpacing:"0.13em",color:"rgba(197,158,71,0.5)",marginLeft:5},
    err:       {fontSize:12,color:"#f87171",letterSpacing:"0.04em"},
    alertBadge:{position:"absolute",top:0,left:0,background:"rgba(74,222,128,0.15)",border:"1px solid rgba(74,222,128,0.35)",color:"#4ade80",fontSize:8,letterSpacing:"0.1em",padding:"2px 7px"},

    // detail panel
    overlay:   {position:"fixed",inset:0,background:"rgba(4,3,2,0.9)",zIndex:100,display:"flex",alignItems:"center",justifyContent:"center",backdropFilter:"blur(8px)"},
    panel:     {background:"#0c0904",border:`1px solid rgba(197,158,71,0.36)`,width:"min(660px,96vw)",maxHeight:"90vh",overflowY:"auto",padding:"32px 28px",position:"relative",animation:"fadeUp 0.3s ease"},
    closeBtn:  {position:"absolute",top:12,right:15,background:"none",border:"none",color:"rgba(197,158,71,0.5)",fontSize:18,cursor:"pointer"},
    panelTitle:{fontFamily:"'Cormorant Garamond',serif",fontSize:23,fontWeight:400,color:text,marginBottom:22,letterSpacing:"0.05em",borderBottom:`1px solid ${gold2}`,paddingBottom:13},
    panelHead: {display:"flex",gap:20,alignItems:"center",marginBottom:20},
    dRow:      {display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 0",borderBottom:`1px solid rgba(197,158,71,0.07)`},
    dLbl:      {fontSize:10,letterSpacing:"0.2em",textTransform:"uppercase",color:"rgba(197,158,71,0.42)"},
    dVal:      {fontSize:13,fontWeight:500,color:text,textAlign:"right",maxWidth:"60%"},
    note:      {marginTop:16,padding:"12px 14px",background:gold3,border:`1px solid rgba(197,158,71,0.12)`,fontSize:12,lineHeight:1.65,color:"rgba(232,213,163,0.62)",fontStyle:"italic"},
    linkA:     {display:"inline-block",marginTop:14,fontSize:10,letterSpacing:"0.17em",textTransform:"uppercase",color:gold,textDecoration:"none",border:`1px solid rgba(197,158,71,0.3)`,padding:"7px 14px"},
    retryBtn:  {fontFamily:"'Rajdhani',sans-serif",fontSize:11,letterSpacing:"0.16em",textTransform:"uppercase",background:"transparent",border:`1px solid rgba(197,158,71,0.35)`,color:gold,padding:"8px 18px",cursor:"pointer",width:"100%",marginTop:12},
    chartWrap: {marginTop:22,paddingTop:16,borderTop:`1px solid ${gold2}`},
    chartTitle:{fontSize:10,letterSpacing:"0.2em",textTransform:"uppercase",color:"rgba(197,158,71,0.45)",marginBottom:12},
    alertRow:  {display:"flex",gap:8,marginTop:14,alignItems:"center"},
    alertInp:  {fontFamily:"'Rajdhani',sans-serif",flex:1,fontSize:13,background:"transparent",border:`1px solid ${gold2}`,color:text,padding:"7px 10px",outline:"none"},
    alertBtn:  {fontFamily:"'Rajdhani',sans-serif",fontSize:11,letterSpacing:"0.14em",textTransform:"uppercase",background:"transparent",border:`1px solid rgba(197,158,71,0.38)`,color:gold,padding:"7px 14px",cursor:"pointer"},

    // watchlist
    watchEmpty:{textAlign:"center",padding:"60px 0",color:"rgba(197,158,71,0.35)",fontSize:14,letterSpacing:"0.2em"},
    wCard:     {background:"rgba(10,8,4,0.9)",border:`1px solid ${gold2}`,padding:"18px 20px",display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10,transition:"border-color 0.2s",cursor:"pointer"},

    // compare
    compBanner:{background:gold3,border:`1px solid ${gold2}`,padding:"10px 18px",fontSize:12,letterSpacing:"0.12em",color:"rgba(197,158,71,0.6)",marginBottom:20,textAlign:"center"},
    compTable: {width:"100%",borderCollapse:"collapse",fontFamily:"'Rajdhani',sans-serif"},
    compTh:    {fontFamily:"'Cormorant Garamond',serif",fontSize:14,fontWeight:600,color:text,padding:"10px 14px",borderBottom:`1px solid ${gold2}`,textAlign:"left",letterSpacing:"0.04em"},
    compTd:    {fontSize:12,letterSpacing:"0.06em",padding:"9px 14px",borderBottom:`1px solid rgba(197,158,71,0.07)`,color:"rgba(232,213,163,0.75)",verticalAlign:"top"},
    compLbl:   {fontSize:10,letterSpacing:"0.18em",textTransform:"uppercase",color:"rgba(197,158,71,0.4)",padding:"9px 14px",borderBottom:`1px solid rgba(197,158,71,0.07)`,fontFamily:"'Rajdhani',sans-serif"},

    // toast
    alertToast:{position:"fixed",bottom:24,right:24,zIndex:200,display:"flex",flexDirection:"column",gap:8},
    toast:     {background:"#0c0904",border:"1px solid rgba(74,222,128,0.5)",padding:"12px 18px",fontSize:12,letterSpacing:"0.07em",color:text,maxWidth:300,animation:"fadeUp 0.3s ease",boxShadow:"0 0 18px rgba(74,222,128,0.15)"},
  };

  const getDialHex = (colorId) => DIAL_COLORS.find(d=>d.id===colorId)?.hex || "#1a1a1a";

  const CardActionBtns = ({model}) => {
    const inWatch=watchlist.includes(model), inCompare=compareSet.includes(model);
    return (
      <div style={s.cardBtns}>
        <button style={s.iconBtn(inWatch,"197,158,71")} onClick={e=>{e.stopPropagation();toggleWatchlist(model);}}>{inWatch?"★ Saved":"☆ Watch"}</button>
        <button style={s.iconBtn(inCompare,"130,180,255")} onClick={e=>{e.stopPropagation();toggleCompare(model);}}>{inCompare?"✓ Compare":"+ Compare"}</button>
      </div>
    );
  };

  const AlertBadge = ({model}) => alerts[model] ? <div style={s.alertBadge}>🔔 {fmt(alerts[model])}</div> : null;

  // ── GRID TAB ─────────────────────────────────────────────────────────────────
  const GridTab = () => {
    const hasColorOrSize = colorFilter !== "All" || sizeFilter !== "All";
    return (
      <>
        <div style={s.scanWrap}>
          <button style={{...s.scanBtn,opacity:scanning?0.5:1}} onClick={scanAll} disabled={scanning}
            onMouseEnter={e=>{if(!scanning)e.target.style.background="rgba(197,158,71,0.07)";}}
            onMouseLeave={e=>{e.target.style.background="transparent";}}>
            {scanning?`⟳  SCANNING — ${progress}%`:"⟳  SCAN ALL 15 ROLEX MODELS"}
          </button>
          {progress>0&&(<><div style={s.progOut}><div style={{...s.progIn,width:`${progress}%`}}/></div><span style={s.progLbl}>{progress}% COMPLETE</span></>)}
          {scanDone&&bestDeal&&(<div style={s.banner}>🏆 <strong>BEST DEAL:</strong> {bestDeal.model} · <strong style={{color:gold}}>{fmt(bestDeal.lowestPrice)}</strong> via {bestDeal.source}</div>)}
        </div>

        {/* ── Filter Panel ── */}
        <div style={s.filterPanel}>

          {/* Row 1: text search + condition + sort */}
          <div style={s.filterRow}>
            <span style={s.filterLbl}>Search</span>
            <input style={s.searchInp} placeholder="Model name…" value={searchQ} onChange={e=>setSearchQ(e.target.value)}/>
            <span style={{...s.filterLbl,marginLeft:8}}>Condition</span>
            <select style={s.selEl} value={condFilter} onChange={e=>setCondFilter(e.target.value)}>
              {CONDITION_FILTERS.map(c=><option key={c}>{c}</option>)}
            </select>
            <span style={{...s.filterLbl,marginLeft:8}}>Sort</span>
            <select style={s.selEl} value={sortBy} onChange={e=>setSortBy(e.target.value)}>
              {SORT_OPTIONS.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <span style={{...s.filterLbl,marginLeft:"auto",fontSize:10,minWidth:"auto"}}>
              {filteredModels.length}/{ROLEX_MODELS.length}
            </span>
          </div>

          <div style={s.divider}/>

          {/* Row 2: dial colour swatches */}
          <div style={{...s.filterRow,marginBottom:10}}>
            <span style={{...s.filterLbl,alignSelf:"center"}}>Dial Color</span>
            <div style={s.swatchRow}>
              {DIAL_COLORS.map(dc=>(
                <div key={dc.id} title={dc.label}
                  style={s.swatch(colorFilter===dc.id, dc.hex, dc.border)}
                  onClick={()=>setColorFilter(dc.id)}>
                  {dc.id==="All" && <span style={s.swatchAll}>ALL</span>}
                  {colorFilter===dc.id && dc.id!=="All" && (
                    <svg style={{position:"absolute",width:"100%",height:"100%"}} viewBox="0 0 26 26">
                      <polyline points="7,13 11,17 19,9" fill="none" stroke={["White","Silver","Pink","Champagne"].includes(dc.id)?"#333":"#fff"} strokeWidth="2.5" strokeLinecap="round"/>
                    </svg>
                  )}
                </div>
              ))}
              {colorFilter!=="All" && (
                <span style={{fontSize:11,color:"rgba(197,158,71,0.6)",letterSpacing:"0.1em",alignSelf:"center"}}>
                  {DIAL_COLORS.find(d=>d.id===colorFilter)?.label}
                </span>
              )}
            </div>
          </div>

          {/* Row 3: case size pills */}
          <div style={s.filterRow}>
            <span style={{...s.filterLbl,alignSelf:"center"}}>Case Size</span>
            <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
              {CASE_SIZES.map(sz=>(
                <button key={sz} style={s.sizePill(sizeFilter===sz)} onClick={()=>setSizeFilter(sz)}>{sz}</button>
              ))}
            </div>
          </div>

          {/* Active filter summary + search button */}
          {hasColorOrSize && (
            <div style={{marginTop:10,display:"flex",gap:10,alignItems:"center",flexWrap:"wrap"}}>
              <div style={{fontSize:11,letterSpacing:"0.1em",color:"rgba(197,158,71,0.55)"}}>
                Searching:
                {colorFilter!=="All"&&<span style={{color:gold,marginLeft:6}}>{colorFilter} dial</span>}
                {sizeFilter!=="All"&&<span style={{color:gold,marginLeft:6}}>{sizeFilter}</span>}
              </div>
              <button style={{...s.sizePill(true),padding:"5px 16px",fontSize:11}}
                onClick={()=>{
                  ROLEX_MODELS.forEach(m=>fetchModel(m,{
                    dialColor:colorFilter!=="All"?colorFilter:undefined,
                    caseSize:sizeFilter!=="All"?sizeFilter:undefined,
                  }));
                }}>
                🔍 Search with Filters
              </button>
              <button style={{...s.sizePill(false),padding:"5px 12px",fontSize:10,color:"rgba(248,113,113,0.7)",borderColor:"rgba(248,113,113,0.25)"}}
                onClick={()=>{setColorFilter("All");setSizeFilter("All");}}>
                ✕ Clear
              </button>
            </div>
          )}
        </div>

        {/* Cards */}
        <div style={s.grid}>
          {filteredModels.map((model,idx)=>{
            const key   = activeKey(model);
            const res   = results[key];
            const isLoad= loading[key];
            const isBest= bestDeal&&res?.lowestPrice!=null&&res.lowestPrice===bestDeal.lowestPrice;
            const dialColorId = res?.dialColor ? DIAL_COLORS.find(d=>res.dialColor.toLowerCase().includes(d.id.toLowerCase()))?.id : null;
            const dialHex = dialColorId ? getDialHex(dialColorId) : null;
            return (
              <div key={model} style={s.card(isBest,idx)}
                onClick={()=>res&&!isLoad&&setSelected(model)}
                onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(197,158,71,0.48)";e.currentTarget.style.transform="translateY(-2px)";}}
                onMouseLeave={e=>{e.currentTarget.style.borderColor=isBest?"rgba(197,158,71,0.6)":gold2;e.currentTarget.style.transform="translateY(0)";}}>
                {isBest&&<div style={s.bestTag}>BEST DEAL</div>}
                <AlertBadge model={model}/>
                <div style={s.cardHead}>
                  {res?.dialColor && <WatchFace dialColor={dialColorId||"Black"} size={48}/>}
                  <div style={s.modelName}>{model}</div>
                </div>

                {isLoad?(
                  <div style={s.dotWrap}>{[0,0.2,0.4].map((d,i)=><span key={i} style={s.dot(d)}/>)}<span style={s.scanTxt}>Scanning…</span></div>
                ):res?(
                  res.error?(
                    <><span style={s.err}>⚠ {res.error}</span><button style={{...s.retryBtn,marginTop:8,padding:"5px 10px",fontSize:9}} onClick={e=>{e.stopPropagation();fetchModel(model,{dialColor:colorFilter!=="All"?colorFilter:undefined,caseSize:sizeFilter!=="All"?sizeFilter:undefined});}}>Retry</button></>
                  ):(
                    <>
                      <span style={s.priceNum}>{fmt(res.lowestPrice)}</span>
                      {res.savings>0&&<span style={s.savTag}>↓ Save {fmt(res.savings)} vs MSRP</span>}
                      <div style={s.metaRow}>
                        {dialHex && <span style={s.dialBadge(dialHex)}><span style={s.dialDot(dialHex)}/>{res.dialColor}</span>}
                        {res.caseSize  &&<span style={s.metaPill}>⌀ {res.caseSize}</span>}
                        {res.material  &&<span style={s.metaPill}>{res.material}</span>}
                        {res.source    &&<span style={s.metaPill}>📍 {res.source}</span>}
                        {res.condition &&<span style={s.metaPill}>{res.condition}</span>}
                        {res.verified  &&<span style={s.verBadge}>✓ Verified</span>}
                      </div>
                      <CardActionBtns model={model}/>
                    </>
                  )
                ):(
                  <button style={s.fetchBtn}
                    onClick={e=>{e.stopPropagation();fetchModel(model,{dialColor:colorFilter!=="All"?colorFilter:undefined,caseSize:sizeFilter!=="All"?sizeFilter:undefined});}}
                    onMouseEnter={e=>{e.target.style.borderColor="rgba(197,158,71,0.65)";e.target.style.color=gold;}}
                    onMouseLeave={e=>{e.target.style.borderColor="rgba(197,158,71,0.3)";e.target.style.color="rgba(197,158,71,0.6)";}}>
                    Search Price
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </>
    );
  };

  // ── WATCHLIST TAB ─────────────────────────────────────────────────────────────
  const WatchlistTab = () => (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,fontWeight:400,letterSpacing:"0.06em"}}>My Watchlist</div>
          <div style={{fontSize:11,letterSpacing:"0.2em",color:"rgba(197,158,71,0.4)",marginTop:4,textTransform:"uppercase"}}>Set price alerts · Track your favourites</div>
        </div>
        <div style={{fontSize:11,letterSpacing:"0.15em",color:"rgba(197,158,71,0.4)"}}>{watchlist.length} model{watchlist.length!==1?"s":""} saved</div>
      </div>
      {watchlist.length===0?(
        <div style={s.watchEmpty}><div style={{fontSize:32,marginBottom:14,opacity:0.3}}>☆</div>No watches saved yet.<br/><span style={{fontSize:11,letterSpacing:"0.15em"}}>TAP ☆ WATCH ON ANY MODEL CARD</span></div>
      ):watchlist.map(model=>{
        const key=activeKey(model), res=results[key], isLoad=loading[key];
        const dialColorId=res?.dialColor?DIAL_COLORS.find(d=>res.dialColor.toLowerCase().includes(d.id.toLowerCase()))?.id:null;
        return (
          <div key={model} style={s.wCard} onClick={()=>res&&setSelected(model)}
            onMouseEnter={e=>e.currentTarget.style.borderColor="rgba(197,158,71,0.45)"}
            onMouseLeave={e=>e.currentTarget.style.borderColor=gold2}>
            <div style={{display:"flex",gap:14,alignItems:"center",flex:1}}>
              {dialColorId&&<WatchFace dialColor={dialColorId} size={44}/>}
              <div>
                <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,color:text,marginBottom:4}}>{model}</div>
                {res?.dialColor&&<span style={{fontSize:10,color:"rgba(197,158,71,0.5)",letterSpacing:"0.1em"}}>{res.dialColor} · {res.caseSize||"—"}</span>}
                {isLoad?(<div style={s.dotWrap}>{[0,0.2,0.4].map((d,i)=><span key={i} style={s.dot(d)}/>)}<span style={s.scanTxt}>Scanning…</span></div>
                ):res?.lowestPrice?(
                  <div style={{marginTop:4}}><span style={{color:gold,fontFamily:"'Cormorant Garamond',serif",fontSize:20}}>{fmt(res.lowestPrice)}</span>{res.savings>0&&<span style={{...s.savTag,display:"inline",marginLeft:10}}>↓ {fmt(res.savings)} off</span>}{res.source&&<div style={{fontSize:10,color:"rgba(197,158,71,0.4)",marginTop:2,letterSpacing:"0.1em"}}>via {res.source}</div>}</div>
                ):(<button style={{...s.fetchBtn,width:"auto",padding:"5px 14px",fontSize:10,marginTop:6}} onClick={e=>{e.stopPropagation();fetchModel(model);}}>Search Price</button>)}
                <div style={{display:"flex",gap:7,marginTop:8,alignItems:"center"}} onClick={e=>e.stopPropagation()}>
                  <input style={{...s.alertInp,width:130,fontSize:12}} placeholder={alerts[model]?`Alert: ${fmt(alerts[model])}`:"Set alert price…"} value={alertInput[model]||""} onChange={e=>setAlertInput(ai=>({...ai,[model]:e.target.value}))} type="number"/>
                  <button style={{...s.alertBtn,fontSize:10}} onClick={()=>setAlert(model)}>{alerts[model]?"Update 🔔":"Set Alert 🔔"}</button>
                  {alerts[model]&&<button style={{...s.alertBtn,fontSize:10,borderColor:"rgba(248,113,113,0.3)",color:"#f87171"}} onClick={()=>setAlerts(a=>{const n={...a};delete n[model];return n;})}>✕</button>}
                </div>
              </div>
            </div>
            <button style={{background:"none",border:"none",color:"rgba(197,158,71,0.45)",fontSize:18,cursor:"pointer"}} onClick={e=>{e.stopPropagation();toggleWatchlist(model);}}>✕</button>
          </div>
        );
      })}
    </div>
  );

  // ── COMPARE TAB ───────────────────────────────────────────────────────────────
  const CompareTab = () => {
    const cols=compareSet.map(m=>results[activeKey(m)]||{model:m});
    const bestP=cols.reduce((min,c)=>c.lowestPrice&&(!min||c.lowestPrice<min)?c.lowestPrice:min,null);
    const rows=[
      {label:"Lowest Price",key:"lowestPrice",render:v=><span style={{color:gold,fontFamily:"'Cormorant Garamond',serif",fontSize:17}}>{fmt(v)}</span>},
      {label:"Retail MSRP",key:"retailMSRP",render:v=>fmt(v)},
      {label:"Savings",key:"savings",render:v=>v>0?<span style={{color:"#4ade80"}}>{fmt(v)}</span>:"—"},
      {label:"Dial Color",key:"dialColor",render:(v,model)=>{
        const dc=DIAL_COLORS.find(d=>v?.toLowerCase().includes(d.id.toLowerCase()));
        return dc?<span style={{display:"inline-flex",alignItems:"center",gap:5}}><span style={{width:12,height:12,borderRadius:"50%",background:dc.hex,border:"1px solid rgba(255,255,255,0.2)",display:"inline-block"}}/>{v}</span>:v||"—";
      }},
      {label:"Case Size",key:"caseSize",render:v=>v||"—"},
      {label:"Material",key:"material",render:v=>v||"—"},
      {label:"Bracelet",key:"bracelet",render:v=>v||"—"},
      {label:"Condition",key:"condition",render:v=>v||"—"},
      {label:"Source",key:"source",render:v=>v||"—"},
      {label:"Reference",key:"referenceNumber",render:v=>v||"—"},
      {label:"Price Range",key:"priceRange",render:v=>v?`${fmt(v.low)} – ${fmt(v.high)}`:"—"},
      {label:"Verified",key:"verified",render:v=>v?<span style={{color:"#4ade80"}}>✓ Yes</span>:<span style={{color:"#f87171"}}>✗ No</span>},
    ];
    return (
      <div>
        <div style={s.compBanner}>SELECT UP TO 3 MODELS FROM THE GRID TAB TO COMPARE · {compareSet.length}/3 SELECTED</div>
        {compareSet.length===0?(
          <div style={s.watchEmpty}><div style={{fontSize:32,marginBottom:14,opacity:0.3}}>⚖</div>No models selected.<br/><span style={{fontSize:11,letterSpacing:"0.15em"}}>TAP "+ COMPARE" ON ANY MODEL CARD</span></div>
        ):(
          <div style={{overflowX:"auto"}}>
            <table style={s.compTable}>
              <thead>
                <tr>
                  <th style={{...s.compTh,width:120,color:"rgba(197,158,71,0.4)",fontSize:10,letterSpacing:"0.2em",fontFamily:"'Rajdhani',sans-serif"}}>ATTRIBUTE</th>
                  {cols.map(c=>{
                    const dc=c.dialColor?DIAL_COLORS.find(d=>c.dialColor.toLowerCase().includes(d.id.toLowerCase())):null;
                    return (
                      <th key={c.model} style={s.compTh}>
                        <div style={{display:"flex",flexDirection:"column",alignItems:"flex-start",gap:8}}>
                          {dc&&<WatchFace dialColor={dc.id} size={44}/>}
                          <div>{c.model}</div>
                          {c.lowestPrice===bestP&&bestP&&<span style={{fontSize:9,background:gold,color:bg,padding:"1px 6px",letterSpacing:"0.1em"}}>LOWEST</span>}
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                {rows.map(row=>(
                  <tr key={row.label}>
                    <td style={{...s.compTd,...s.compLbl}}>{row.label}</td>
                    {cols.map(c=><td key={c.model} style={s.compTd}>{loading[activeKey(c.model)]?<span style={{color:"rgba(197,158,71,0.4)",fontSize:10}}>Scanning…</span>:row.render(c[row.key],c.model)}</td>)}
                  </tr>
                ))}
                <tr>
                  <td style={{...s.compTd,...s.compLbl}}>Price Trend</td>
                  {cols.map(c=>{
                    const h=history[activeKey(c.model)];
                    return <td key={c.model} style={{...s.compTd,padding:"10px 14px"}}>{h?<ResponsiveContainer width="100%" height={70}><LineChart data={h} margin={{top:4,right:4,bottom:0,left:0}}><Line type="monotone" dataKey="price" stroke={gold} strokeWidth={1.5} dot={false}/></LineChart></ResponsiveContainer>:<span style={{color:"rgba(197,158,71,0.3)",fontSize:10}}>No data</span>}</td>;
                  })}
                </tr>
              </tbody>
            </table>
            <button style={{...s.retryBtn,width:"auto",marginTop:16,padding:"8px 22px"}} onClick={()=>setCompareSet([])}>Clear Comparison</button>
          </div>
        )}
      </div>
    );
  };

  // ── DETAIL PANEL ──────────────────────────────────────────────────────────────
  const DetailPanel = () => {
    if(!selected) return null;
    const hist=history[selectedKey];
    const minP=hist?Math.min(...hist.map(h=>h.price)):null;
    const maxP=hist?Math.max(...hist.map(h=>h.price)):null;
    const dialColorId=selectedData?.dialColor?DIAL_COLORS.find(d=>selectedData.dialColor.toLowerCase().includes(d.id.toLowerCase()))?.id:null;
    return (
      <div style={s.overlay} onClick={()=>setSelected(null)}>
        <div style={s.panel} onClick={e=>e.stopPropagation()}>
          <button style={s.closeBtn} onClick={()=>setSelected(null)}>✕</button>
          <h2 style={s.panelTitle}>{selected}</h2>

          {loading[selectedKey]?(
            <p style={{color:"rgba(197,158,71,0.5)",fontSize:12,letterSpacing:"0.15em"}}>Scanning live markets…</p>
          ):selectedData?(
            selectedData.error?(
              <><p style={s.err}>{selectedData.error}</p><button style={s.retryBtn} onClick={()=>fetchModel(selected)}>Retry Search</button></>
            ):(
              <>
                {/* Watch face + spec header */}
                <div style={s.panelHead}>
                  {dialColorId&&<WatchFace dialColor={dialColorId} size={80}/>}
                  <div>
                    {selectedData.dialColor&&<div style={{fontSize:13,color:"rgba(197,158,71,0.7)",letterSpacing:"0.1em",marginBottom:4}}>◉ {selectedData.dialColor} Dial</div>}
                    {selectedData.caseSize&&<div style={{fontSize:12,color:"rgba(197,158,71,0.55)",letterSpacing:"0.1em",marginBottom:4}}>⌀ {selectedData.caseSize}</div>}
                    {selectedData.material&&<div style={{fontSize:12,color:"rgba(197,158,71,0.55)",letterSpacing:"0.1em",marginBottom:4}}>◈ {selectedData.material}</div>}
                    {selectedData.bracelet&&<div style={{fontSize:12,color:"rgba(197,158,71,0.55)",letterSpacing:"0.1em"}}>⬡ {selectedData.bracelet} Bracelet</div>}
                  </div>
                </div>

                {[
                  ["Lowest Price Found",<span style={{color:gold,fontSize:21,fontFamily:"'Cormorant Garamond',serif"}}>{fmt(selectedData.lowestPrice)}</span>],
                  ["Retail MSRP",fmt(selectedData.retailMSRP)],
                  ["Potential Savings",selectedData.savings>0?<span style={{color:"#4ade80"}}>{fmt(selectedData.savings)}</span>:"—"],
                  ["Best Source",selectedData.source||"—"],
                  ["Condition",selectedData.condition||"—"],
                  ["Reference Number",selectedData.referenceNumber||"—"],
                  ["Market Price Range",selectedData.priceRange?`${fmt(selectedData.priceRange.low)} – ${fmt(selectedData.priceRange.high)}`:"—"],
                  ["Data Verified",selectedData.verified?<span style={{color:"#4ade80"}}>✓ Yes</span>:<span style={{color:"#f87171"}}>✗ No</span>],
                ].map(([lbl,val])=>(
                  <div key={lbl} style={s.dRow}><span style={s.dLbl}>{lbl}</span><span style={s.dVal}>{val}</span></div>
                ))}

                {selectedData.marketNote&&<div style={s.note}>"{selectedData.marketNote}"</div>}

                {hist&&(
                  <div style={s.chartWrap}>
                    <div style={s.chartTitle}>6-MONTH PRICE TREND · Low: {fmt(minP)} · High: {fmt(maxP)}</div>
                    <ResponsiveContainer width="100%" height={130}>
                      <LineChart data={hist} margin={{top:4,right:8,bottom:0,left:0}}>
                        <XAxis dataKey="month" tick={{fill:"rgba(197,158,71,0.4)",fontSize:9,fontFamily:"'Rajdhani',sans-serif",letterSpacing:"0.1em"}} axisLine={false} tickLine={false}/>
                        <YAxis domain={["auto","auto"]} tick={{fill:"rgba(197,158,71,0.3)",fontSize:8}} axisLine={false} tickLine={false} tickFormatter={v=>"$"+Math.round(v/1000)+"k"} width={36}/>
                        <Tooltip content={<ChartTooltip/>}/>
                        <ReferenceLine y={selectedData.lowestPrice} stroke="rgba(74,222,128,0.35)" strokeDasharray="3 3"/>
                        <Line type="monotone" dataKey="price" stroke={gold} strokeWidth={2} dot={{fill:gold,r:2.5}} activeDot={{r:4,fill:gold}}/>
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                )}

                <div style={{marginTop:18,paddingTop:14,borderTop:`1px solid ${gold2}`}}>
                  <div style={{fontSize:10,letterSpacing:"0.2em",textTransform:"uppercase",color:"rgba(197,158,71,0.4)",marginBottom:8}}>🔔 Price Alert</div>
                  <div style={s.alertRow}>
                    <input style={s.alertInp} type="number" placeholder={alerts[selected]?`Current: ${fmt(alerts[selected])}`:"Enter target price…"} value={alertInput[selected]||""} onChange={e=>setAlertInput(ai=>({...ai,[selected]:e.target.value}))}/>
                    <button style={s.alertBtn} onClick={()=>setAlert(selected)}>{alerts[selected]?"Update":"Set Alert"}</button>
                    {alerts[selected]&&<button style={{...s.alertBtn,borderColor:"rgba(248,113,113,0.3)",color:"#f87171"}} onClick={()=>setAlerts(a=>{const n={...a};delete n[selected];return n;})}>Remove</button>}
                  </div>
                </div>

                <div style={{display:"flex",gap:10,marginTop:14,flexWrap:"wrap"}}>
                  {selectedData.sourceUrl&&<a href={selectedData.sourceUrl} target="_blank" rel="noopener noreferrer" style={s.linkA}>VIEW LISTING →</a>}
                  <button style={{...s.linkA,cursor:"pointer",background:"none"}} onClick={()=>toggleWatchlist(selected)}>{watchlist.includes(selected)?"★ SAVED":"☆ ADD TO WATCHLIST"}</button>
                  <button style={{...s.linkA,cursor:"pointer",background:"none",borderColor:"rgba(130,180,255,0.3)",color:"rgba(130,180,255,0.8)"}} onClick={()=>{toggleCompare(selected);setSelected(null);setTab("COMPARE");}}>+ COMPARE</button>
                </div>
              </>
            )
          ):(
            <button style={s.retryBtn} onClick={()=>fetchModel(selected)}>Search Now</button>
          )}
        </div>
      </div>
    );
  };

  // ── ROOT ──────────────────────────────────────────────────────────────────────
  return (
    <div style={s.root}>
      <canvas ref={canvasRef} style={s.canvas}/>
      <div style={s.wrap}>
        <header style={s.header}>
          <span style={s.crown}>♛</span>
          <h1 style={s.title}>ROLEX PRICE INTELLIGENCE</h1>
          <p style={s.sub}>Live Web Scan · Dial Color & Size Search · AI-Verified · Price Alerts</p>
        </header>

        <div style={s.tabBar}>
          {TABS.map(t=>(
            <button key={t} style={s.tabBtn(tab===t)} onClick={()=>setTab(t)}>
              {t==="WATCHLIST"?`${t}${watchlist.length?` (${watchlist.length})`:""}`:t==="COMPARE"?`${t}${compareSet.length?` (${compareSet.length})`:""}`:t}
            </button>
          ))}
        </div>

        {tab==="GRID"      &&<GridTab/>}
        {tab==="WATCHLIST" &&<WatchlistTab/>}
        {tab==="COMPARE"   &&<CompareTab/>}
      </div>

      <DetailPanel/>

      {triggered.length>0&&(
        <div style={s.alertToast}>
          {triggered.slice(-3).map((f,i)=>(
            <div key={i} style={s.toast}>
              <div style={{color:"#4ade80",fontSize:10,letterSpacing:"0.15em",marginBottom:4}}>🔔 PRICE ALERT TRIGGERED</div>
              <strong>{f.model}</strong><br/>
              Current: <span style={{color:gold}}>{fmt(f.price)}</span> · Target: {fmt(f.target)}
              <button style={{float:"right",background:"none",border:"none",color:"rgba(232,213,163,0.4)",cursor:"pointer",marginTop:-2}} onClick={()=>setTriggered(tt=>tt.filter((_,j)=>j!==i))}>✕</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
