# Rolex Price Intelligence — iOS App Setup

## Requirements
- Mac computer with Xcode installed
- Node.js installed (https://nodejs.org)
- Apple Developer Account ($99/year) at developer.apple.com

## Steps to run and build for iOS

### 1. Open Terminal and navigate to this folder
```
cd rolex-price-app
```

### 2. Install dependencies
```
npm install
```

### 3. Build the app
```
npm run build
```

### 4. Copy build to iOS
```
npx cap copy ios
```

### 5. Open in Xcode
```
npx cap open ios
```

### 6. In Xcode
- Click on the project name in the left panel
- Under "Signing & Capabilities", sign in with your Apple Developer account
- Change the Bundle Identifier from "com.yourname.rolexprice" to something unique
- Press the ▶ Play button to test in the simulator

### 7. Submit to App Store
- In Xcode: Product → Archive
- Click "Distribute App" → "App Store Connect"
- Go to appstoreconnect.apple.com to complete your listing

## Notes
- Your Anthropic API key is currently embedded in the app frontend.
- Before App Store submission, consider routing API calls through a backend server.
